# some cursors for pygame
import pygame
NORMAL = pygame.SYSTEM_CURSOR_ARROW
HAND = pygame.SYSTEM_CURSOR_HAND
RESIZEALL = pygame.SYSTEM_CURSOR_SIZEALL